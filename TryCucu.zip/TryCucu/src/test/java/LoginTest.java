import org.testng.annotations.Test;
import pages.*;

public class LoginTest extends BaseTest {

    @Test
    public void LoginAmazon() {

        LogIn logIn = new LogIn(driver);

        logIn.navigateToAmazonHome();
        logIn.SigninHome();
        logIn.EnterLoginDetails();
    }

    @Test
    public void SignUp() {
        SignUp signup = new SignUp(driver);
        signup.navigateToAmazonHome();
        signup.SigninHome();
        signup.EnterSignupDetais();
    }

    @Test
    public void Cart() {
        Cart cart = new Cart(driver);
        cart.navigateToAmazonHome();
        cart.SelectCart();
        cart.EnterLoginDetails();
    }

    @Test
    public void CustomerserviceTest(){
        CustomerService customerService = new CustomerService(driver);
        customerService.navigateToAmazonHome();
        customerService.CustServices();
        customerService.EnterLoginDetails();
    }

}

